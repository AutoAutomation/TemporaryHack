No Sleep

- Prevent the computer from idle going into sleep mode

No Sleep is freeware that prevent computer from idle going into sleep mode, user sometime execute long time task that interrupted by windows system going into sleep mode for long time idle, this utility will keep windows system running from going into sleep mode.

This tools also has function that turn computer into sleep mode after a period time, etc 60 minutes.


Unzip it, run nosleep.exe.
it supports windows xp/2003/vista/7/2008.


copyright 2010 flyos software
website: http://www.flyos.net
